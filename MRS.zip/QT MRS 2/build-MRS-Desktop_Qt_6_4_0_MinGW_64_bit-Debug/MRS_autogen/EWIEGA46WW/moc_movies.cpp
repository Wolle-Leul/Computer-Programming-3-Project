/****************************************************************************
** Meta object code from reading C++ file 'movies.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../MRS/movies.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'movies.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_movies_t {
    uint offsetsAndSizes[34];
    char stringdata0[7];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[19];
    char stringdata5[23];
    char stringdata6[21];
    char stringdata7[21];
    char stringdata8[11];
    char stringdata9[15];
    char stringdata10[21];
    char stringdata11[20];
    char stringdata12[20];
    char stringdata13[24];
    char stringdata14[22];
    char stringdata15[22];
    char stringdata16[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_movies_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_movies_t qt_meta_stringdata_movies = {
    {
        QT_MOC_LITERAL(0, 6),  // "movies"
        QT_MOC_LITERAL(7, 19),  // "actionButtonClicked"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 18),  // "dramaButtonClicked"
        QT_MOC_LITERAL(47, 18),  // "crimeButtonClicked"
        QT_MOC_LITERAL(66, 22),  // "adventureButtonClicked"
        QT_MOC_LITERAL(89, 20),  // "westernButtonClicked"
        QT_MOC_LITERAL(110, 20),  // "similarButtonClicked"
        QT_MOC_LITERAL(131, 10),  // "selectFile"
        QT_MOC_LITERAL(142, 14),  // "recommendMovie"
        QT_MOC_LITERAL(157, 20),  // "recommendActionMovie"
        QT_MOC_LITERAL(178, 19),  // "recommenddramaMovie"
        QT_MOC_LITERAL(198, 19),  // "recommendcrimeMovie"
        QT_MOC_LITERAL(218, 23),  // "recommendadventureMovie"
        QT_MOC_LITERAL(242, 21),  // "recommendwesternMovie"
        QT_MOC_LITERAL(264, 21),  // "recommendSimilarMovie"
        QT_MOC_LITERAL(286, 13)   // "onBackclicked"
    },
    "movies",
    "actionButtonClicked",
    "",
    "dramaButtonClicked",
    "crimeButtonClicked",
    "adventureButtonClicked",
    "westernButtonClicked",
    "similarButtonClicked",
    "selectFile",
    "recommendMovie",
    "recommendActionMovie",
    "recommenddramaMovie",
    "recommendcrimeMovie",
    "recommendadventureMovie",
    "recommendwesternMovie",
    "recommendSimilarMovie",
    "onBackclicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_movies[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x06,    1 /* Public */,
       3,    0,  105,    2, 0x06,    2 /* Public */,
       4,    0,  106,    2, 0x06,    3 /* Public */,
       5,    0,  107,    2, 0x06,    4 /* Public */,
       6,    0,  108,    2, 0x06,    5 /* Public */,
       7,    0,  109,    2, 0x06,    6 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    0,  110,    2, 0x08,    7 /* Private */,
       9,    0,  111,    2, 0x08,    8 /* Private */,
      10,    0,  112,    2, 0x08,    9 /* Private */,
      11,    0,  113,    2, 0x08,   10 /* Private */,
      12,    0,  114,    2, 0x08,   11 /* Private */,
      13,    0,  115,    2, 0x08,   12 /* Private */,
      14,    0,  116,    2, 0x08,   13 /* Private */,
      15,    0,  117,    2, 0x08,   14 /* Private */,
      16,    0,  118,    2, 0x08,   15 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject movies::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_movies.offsetsAndSizes,
    qt_meta_data_movies,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_movies_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<movies, std::true_type>,
        // method 'actionButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dramaButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'crimeButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'adventureButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'westernButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'similarButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommendMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommendActionMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommenddramaMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommendcrimeMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommendadventureMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommendwesternMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recommendSimilarMovie'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onBackclicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void movies::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<movies *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->actionButtonClicked(); break;
        case 1: _t->dramaButtonClicked(); break;
        case 2: _t->crimeButtonClicked(); break;
        case 3: _t->adventureButtonClicked(); break;
        case 4: _t->westernButtonClicked(); break;
        case 5: _t->similarButtonClicked(); break;
        case 6: _t->selectFile(); break;
        case 7: _t->recommendMovie(); break;
        case 8: _t->recommendActionMovie(); break;
        case 9: _t->recommenddramaMovie(); break;
        case 10: _t->recommendcrimeMovie(); break;
        case 11: _t->recommendadventureMovie(); break;
        case 12: _t->recommendwesternMovie(); break;
        case 13: _t->recommendSimilarMovie(); break;
        case 14: _t->onBackclicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (movies::*)();
            if (_t _q_method = &movies::actionButtonClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (movies::*)();
            if (_t _q_method = &movies::dramaButtonClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (movies::*)();
            if (_t _q_method = &movies::crimeButtonClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (movies::*)();
            if (_t _q_method = &movies::adventureButtonClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (movies::*)();
            if (_t _q_method = &movies::westernButtonClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (movies::*)();
            if (_t _q_method = &movies::similarButtonClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }
    (void)_a;
}

const QMetaObject *movies::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *movies::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_movies.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int movies::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void movies::actionButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void movies::dramaButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void movies::crimeButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void movies::adventureButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void movies::westernButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void movies::similarButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
