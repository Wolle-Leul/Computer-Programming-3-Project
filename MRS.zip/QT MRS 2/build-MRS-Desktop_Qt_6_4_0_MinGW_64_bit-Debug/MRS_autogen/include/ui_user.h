/********************************************************************************
** Form generated from reading UI file 'user.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USER_H
#define UI_USER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_user
{
public:
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *uname2;
    QLineEdit *passd2;
    QPushButton *Ulogin;
    QLabel *statusu;
    QLabel *lwelcome;
    QLabel *ll;
    QPushButton *pushButton;
    QPushButton *refresh;

    void setupUi(QWidget *user)
    {
        if (user->objectName().isEmpty())
            user->setObjectName("user");
        user->resize(800, 600);
        groupBox = new QGroupBox(user);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(310, 270, 391, 251));
        label = new QLabel(groupBox);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 80, 101, 41));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 140, 101, 41));
        uname2 = new QLineEdit(groupBox);
        uname2->setObjectName("uname2");
        uname2->setGeometry(QRect(140, 90, 211, 28));
        passd2 = new QLineEdit(groupBox);
        passd2->setObjectName("passd2");
        passd2->setGeometry(QRect(140, 140, 211, 28));
        passd2->setEchoMode(QLineEdit::Password);
        Ulogin = new QPushButton(groupBox);
        Ulogin->setObjectName("Ulogin");
        Ulogin->setGeometry(QRect(190, 200, 111, 29));
        statusu = new QLabel(user);
        statusu->setObjectName("statusu");
        statusu->setGeometry(QRect(20, 570, 671, 20));
        lwelcome = new QLabel(user);
        lwelcome->setObjectName("lwelcome");
        lwelcome->setGeometry(QRect(360, 60, 411, 181));
        ll = new QLabel(user);
        ll->setObjectName("ll");
        ll->setGeometry(QRect(30, 20, 211, 161));
        pushButton = new QPushButton(user);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(690, 20, 83, 29));
        refresh = new QPushButton(user);
        refresh->setObjectName("refresh");
        refresh->setGeometry(QRect(730, 550, 51, 29));

        retranslateUi(user);

        QMetaObject::connectSlotsByName(user);
    } // setupUi

    void retranslateUi(QWidget *user)
    {
        user->setWindowTitle(QCoreApplication::translate("user", "Form", nullptr));
        groupBox->setTitle(QCoreApplication::translate("user", "Sighn in", nullptr));
        label->setText(QCoreApplication::translate("user", "Username", nullptr));
        label_2->setText(QCoreApplication::translate("user", "Password", nullptr));
        Ulogin->setText(QCoreApplication::translate("user", "Login", nullptr));
        statusu->setText(QCoreApplication::translate("user", "[+]", nullptr));
        lwelcome->setText(QString());
        ll->setText(QString());
        pushButton->setText(QCoreApplication::translate("user", "(<-)", nullptr));
        refresh->setText(QCoreApplication::translate("user", "(@)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class user: public Ui_user {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USER_H
