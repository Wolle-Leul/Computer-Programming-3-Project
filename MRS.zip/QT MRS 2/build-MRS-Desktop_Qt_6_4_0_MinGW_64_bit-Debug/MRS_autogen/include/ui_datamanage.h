/********************************************************************************
** Form generated from reading UI file 'datamanage.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DATAMANAGE_H
#define UI_DATAMANAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_datamanage
{
public:
    QLabel *label;
    QFrame *line;
    QFrame *line_2;
    QTableView *tableView;
    QLabel *tablename;
    QLineEdit *id;
    QLineEdit *name;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QLabel *warning;
    QPushButton *Back;

    void setupUi(QDialog *datamanage)
    {
        if (datamanage->objectName().isEmpty())
            datamanage->setObjectName("datamanage");
        datamanage->resize(800, 600);
        label = new QLabel(datamanage);
        label->setObjectName("label");
        label->setGeometry(QRect(40, 60, 211, 71));
        line = new QFrame(datamanage);
        line->setObjectName("line");
        line->setGeometry(QRect(290, 0, 21, 601));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(datamanage);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(300, 380, 501, 20));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        tableView = new QTableView(datamanage);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(310, 60, 481, 321));
        tablename = new QLabel(datamanage);
        tablename->setObjectName("tablename");
        tablename->setGeometry(QRect(500, 20, 211, 41));
        id = new QLineEdit(datamanage);
        id->setObjectName("id");
        id->setGeometry(QRect(470, 480, 321, 28));
        name = new QLineEdit(datamanage);
        name->setObjectName("name");
        name->setGeometry(QRect(470, 440, 321, 28));
        label_2 = new QLabel(datamanage);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(330, 480, 111, 20));
        label_3 = new QLabel(datamanage);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(330, 440, 111, 20));
        pushButton_2 = new QPushButton(datamanage);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(640, 520, 151, 51));
        warning = new QLabel(datamanage);
        warning->setObjectName("warning");
        warning->setGeometry(QRect(360, 400, 381, 20));
        QFont font;
        font.setFamilies({QString::fromUtf8("Stencil")});
        warning->setFont(font);
        Back = new QPushButton(datamanage);
        Back->setObjectName("Back");
        Back->setGeometry(QRect(20, 10, 83, 29));

        retranslateUi(datamanage);

        QMetaObject::connectSlotsByName(datamanage);
    } // setupUi

    void retranslateUi(QDialog *datamanage)
    {
        datamanage->setWindowTitle(QCoreApplication::translate("datamanage", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("datamanage", "Action name", nullptr));
        tablename->setText(QCoreApplication::translate("datamanage", "table name", nullptr));
        label_2->setText(QCoreApplication::translate("datamanage", "password", nullptr));
        label_3->setText(QCoreApplication::translate("datamanage", "Name", nullptr));
        pushButton_2->setText(QCoreApplication::translate("datamanage", "Commit", nullptr));
        warning->setText(QString());
        Back->setText(QCoreApplication::translate("datamanage", "(<-)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class datamanage: public Ui_datamanage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DATAMANAGE_H
