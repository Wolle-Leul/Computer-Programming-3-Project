/********************************************************************************
** Form generated from reading UI file 'admin.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_H
#define UI_ADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_admin
{
public:
    QLabel *status;
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *uname1;
    QLineEdit *passd1;
    QPushButton *Alogin;
    QLabel *ll;
    QLabel *lwelcome;
    QPushButton *Back;
    QPushButton *refresh;

    void setupUi(QWidget *admin)
    {
        if (admin->objectName().isEmpty())
            admin->setObjectName("admin");
        admin->resize(800, 600);
        status = new QLabel(admin);
        status->setObjectName("status");
        status->setGeometry(QRect(10, 570, 721, 20));
        groupBox = new QGroupBox(admin);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(310, 270, 391, 251));
        label = new QLabel(groupBox);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 80, 101, 41));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 140, 101, 41));
        uname1 = new QLineEdit(groupBox);
        uname1->setObjectName("uname1");
        uname1->setGeometry(QRect(140, 90, 211, 28));
        passd1 = new QLineEdit(groupBox);
        passd1->setObjectName("passd1");
        passd1->setGeometry(QRect(140, 140, 211, 28));
        passd1->setEchoMode(QLineEdit::Password);
        Alogin = new QPushButton(groupBox);
        Alogin->setObjectName("Alogin");
        Alogin->setGeometry(QRect(190, 200, 111, 29));
        ll = new QLabel(admin);
        ll->setObjectName("ll");
        ll->setGeometry(QRect(30, 20, 211, 161));
        lwelcome = new QLabel(admin);
        lwelcome->setObjectName("lwelcome");
        lwelcome->setGeometry(QRect(360, 60, 411, 181));
        Back = new QPushButton(admin);
        Back->setObjectName("Back");
        Back->setGeometry(QRect(690, 10, 83, 29));
        refresh = new QPushButton(admin);
        refresh->setObjectName("refresh");
        refresh->setGeometry(QRect(750, 560, 31, 29));

        retranslateUi(admin);

        QMetaObject::connectSlotsByName(admin);
    } // setupUi

    void retranslateUi(QWidget *admin)
    {
        admin->setWindowTitle(QCoreApplication::translate("admin", "Form", nullptr));
        status->setText(QCoreApplication::translate("admin", "[+]", nullptr));
        groupBox->setTitle(QCoreApplication::translate("admin", "Sighn In", nullptr));
        label->setText(QCoreApplication::translate("admin", "Username", nullptr));
        label_2->setText(QCoreApplication::translate("admin", "Password", nullptr));
        Alogin->setText(QCoreApplication::translate("admin", "LogIn", nullptr));
        ll->setText(QString());
        lwelcome->setText(QString());
        Back->setText(QCoreApplication::translate("admin", "(<-)", nullptr));
        refresh->setText(QCoreApplication::translate("admin", "(@)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admin: public Ui_admin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_H
