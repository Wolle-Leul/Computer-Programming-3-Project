/********************************************************************************
** Form generated from reading UI file 'movies.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOVIES_H
#define UI_MOVIES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_movies
{
public:
    QFrame *frame;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *movieTitleLabel;
    QLabel *movieGenreLabel;
    QLabel *movieRatingLabel;
    QLabel *label_7;
    QLineEdit *movieNameEdit;
    QPushButton *similarButton;
    QPushButton *recommendBtn;
    QPushButton *selectFileBtn;
    QPushButton *Back;
    QGroupBox *groupBox;
    QPushButton *dramaButton;
    QPushButton *actionButton;
    QPushButton *crimeButton;
    QPushButton *adventureButton;
    QPushButton *westernButton;
    QLabel *picture;

    void setupUi(QWidget *movies)
    {
        if (movies->objectName().isEmpty())
            movies->setObjectName("movies");
        movies->resize(800, 600);
        frame = new QFrame(movies);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(10, 280, 371, 201));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label = new QLabel(frame);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 40, 63, 20));
        label_2 = new QLabel(frame);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 80, 63, 20));
        label_3 = new QLabel(frame);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(20, 130, 63, 20));
        movieTitleLabel = new QLabel(frame);
        movieTitleLabel->setObjectName("movieTitleLabel");
        movieTitleLabel->setGeometry(QRect(170, 40, 170, 20));
        movieGenreLabel = new QLabel(frame);
        movieGenreLabel->setObjectName("movieGenreLabel");
        movieGenreLabel->setGeometry(QRect(170, 80, 170, 20));
        movieRatingLabel = new QLabel(frame);
        movieRatingLabel->setObjectName("movieRatingLabel");
        movieRatingLabel->setGeometry(QRect(170, 130, 170, 20));
        label_7 = new QLabel(movies);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(10, 490, 41, 20));
        movieNameEdit = new QLineEdit(movies);
        movieNameEdit->setObjectName("movieNameEdit");
        movieNameEdit->setGeometry(QRect(10, 520, 391, 28));
        similarButton = new QPushButton(movies);
        similarButton->setObjectName("similarButton");
        similarButton->setGeometry(QRect(130, 560, 91, 29));
        recommendBtn = new QPushButton(movies);
        recommendBtn->setObjectName("recommendBtn");
        recommendBtn->setGeometry(QRect(620, 380, 141, 29));
        selectFileBtn = new QPushButton(movies);
        selectFileBtn->setObjectName("selectFileBtn");
        selectFileBtn->setGeometry(QRect(640, 570, 151, 29));
        Back = new QPushButton(movies);
        Back->setObjectName("Back");
        Back->setGeometry(QRect(700, 20, 83, 29));
        groupBox = new QGroupBox(movies);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(590, 70, 191, 291));
        dramaButton = new QPushButton(groupBox);
        dramaButton->setObjectName("dramaButton");
        dramaButton->setGeometry(QRect(30, 100, 131, 29));
        actionButton = new QPushButton(groupBox);
        actionButton->setObjectName("actionButton");
        actionButton->setGeometry(QRect(30, 60, 131, 29));
        crimeButton = new QPushButton(groupBox);
        crimeButton->setObjectName("crimeButton");
        crimeButton->setGeometry(QRect(30, 140, 131, 29));
        adventureButton = new QPushButton(groupBox);
        adventureButton->setObjectName("adventureButton");
        adventureButton->setGeometry(QRect(30, 180, 131, 29));
        westernButton = new QPushButton(groupBox);
        westernButton->setObjectName("westernButton");
        westernButton->setGeometry(QRect(30, 220, 131, 29));
        picture = new QLabel(movies);
        picture->setObjectName("picture");
        picture->setGeometry(QRect(10, 10, 501, 181));

        retranslateUi(movies);

        QMetaObject::connectSlotsByName(movies);
    } // setupUi

    void retranslateUi(QWidget *movies)
    {
        movies->setWindowTitle(QCoreApplication::translate("movies", "Form", nullptr));
        label->setText(QCoreApplication::translate("movies", "Title", nullptr));
        label_2->setText(QCoreApplication::translate("movies", "Gener", nullptr));
        label_3->setText(QCoreApplication::translate("movies", "Rating", nullptr));
        movieTitleLabel->setText(QString());
        movieGenreLabel->setText(QString());
        movieRatingLabel->setText(QString());
        label_7->setText(QCoreApplication::translate("movies", "Title", nullptr));
        similarButton->setText(QCoreApplication::translate("movies", "Similar", nullptr));
        recommendBtn->setText(QCoreApplication::translate("movies", "Surprise Me", nullptr));
        selectFileBtn->setText(QCoreApplication::translate("movies", "Select Movie File", nullptr));
        Back->setText(QCoreApplication::translate("movies", "(<-)", nullptr));
        groupBox->setTitle(QCoreApplication::translate("movies", "Geners", nullptr));
        dramaButton->setText(QCoreApplication::translate("movies", "Drama", nullptr));
        actionButton->setText(QCoreApplication::translate("movies", "Action", nullptr));
        crimeButton->setText(QCoreApplication::translate("movies", "Crime", nullptr));
        adventureButton->setText(QCoreApplication::translate("movies", "Advernture", nullptr));
        westernButton->setText(QCoreApplication::translate("movies", "Western", nullptr));
        picture->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class movies: public Ui_movies {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOVIES_H
