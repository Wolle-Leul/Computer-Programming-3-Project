/********************************************************************************
** Form generated from reading UI file 'managedb.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGEDB_H
#define UI_MANAGEDB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_managedb
{
public:
    QPushButton *addusr;
    QPushButton *dltusr;
    QPushButton *Back;

    void setupUi(QDialog *managedb)
    {
        if (managedb->objectName().isEmpty())
            managedb->setObjectName("managedb");
        managedb->resize(800, 600);
        addusr = new QPushButton(managedb);
        addusr->setObjectName("addusr");
        addusr->setGeometry(QRect(170, 250, 431, 51));
        dltusr = new QPushButton(managedb);
        dltusr->setObjectName("dltusr");
        dltusr->setGeometry(QRect(170, 320, 431, 51));
        Back = new QPushButton(managedb);
        Back->setObjectName("Back");
        Back->setGeometry(QRect(40, 30, 83, 29));

        retranslateUi(managedb);

        QMetaObject::connectSlotsByName(managedb);
    } // setupUi

    void retranslateUi(QDialog *managedb)
    {
        managedb->setWindowTitle(QCoreApplication::translate("managedb", "Dialog", nullptr));
        addusr->setText(QCoreApplication::translate("managedb", "Add Users", nullptr));
        dltusr->setText(QCoreApplication::translate("managedb", "Delet User", nullptr));
        Back->setText(QCoreApplication::translate("managedb", "(<-)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class managedb: public Ui_managedb {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGEDB_H
