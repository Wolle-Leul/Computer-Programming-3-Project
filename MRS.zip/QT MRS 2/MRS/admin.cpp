#include "admin.h"
#include "welcome.h"
#include "ui_admin.h"
#include <managedb.h>


# define path "C:/Users/Leul Wolle/Desktop/QT MRS 2/Admins.csv"

admin::admin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::admin),
    file(path)
{
    ui->setupUi(this);
    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/sighn.png");
    QPixmap welcome("C:/Users/Leul Wolle/Desktop/QT MRS 2/Welcome.png");
            ui->ll->setPixmap(ll);
            ui->lwelcome->setPixmap(welcome);

    // Open file for reading and writing
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        ui->status->setText("Failed to open file");
        return;
    }

    // Check if file exists
    QFileInfo checkFile(path);
    if (!checkFile.exists()) {
        ui->status->setText("File not exist");
        return;
    }

    // Check if I have permission
    if (!file.setPermissions(QFile::ReadUser | QFile::WriteUser)) {
        ui->status->setText("Failed to set permissions");
    } else {
        ui->status->setText("Connected.....");
    }
}

admin::~admin()
{
    file.close();
    delete ui;
}

void admin::on_Alogin_clicked()
{
    QString username, password;
    username = ui->uname1->text();
    password = ui->passd1->text();

    if (!file.isOpen()) {
        qDebug() << "Failed to open file";
        ui->status->setText("Failed to open file");
        return;
    }

    // Check if file exists
    QFileInfo checkFile(path);
    if (!checkFile.exists()) {
        ui->status->setText("File not exist");
        return;
    }

    // Read file and check for username and password
    QTextStream in(&file);
    in.readLine(); // skip the header row
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(",");
        if (fields[0] == username && fields[1] == password) {
            ui->status->setText("username and password are correct");
            this->hide();
            managedb*mdbl = new managedb;
            mdbl->show();
        }
    }

    ui->status->setText("username or password is not correct");
    return;
}




void admin::on_Back_clicked()
{
    this->hide();
    welcome*wp = new welcome;
    wp->show();
}


void admin::on_refresh_clicked()
{
    this->hide();
    admin*rf = new admin;
    rf->show();
}

