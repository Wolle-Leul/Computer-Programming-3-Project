#ifndef USER_H
#define USER_H

#include <QWidget>
#include <QtDebug>
#include <QtSql>
#include <QFile>
#include <QTextStream>

namespace Ui {
class user;
}

class user : public QWidget
{
    Q_OBJECT

public:
    explicit user(QWidget *parent = nullptr);
    ~user();

private slots:
    void on_Ulogin_clicked();

    void on_pushButton_clicked();

    void on_refresh_clicked();

private:
    Ui::user *ui;
    QFile file;
};

#endif // USER_H
