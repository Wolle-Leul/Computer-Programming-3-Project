#include <QStandardItemModel>// for table display
#include "datamanage.h"
#include "managedb.h"
#include "ui_datamanage.h"
#define pathusr "C:/Users/Leul Wolle/Desktop/QT MRS 2/Users.csv"


datamanage::datamanage(QWidget *parent, int action) :
    QDialog(parent),
    ui(new Ui::datamanage),
    action(action)

{
    ui->setupUi(this);
        if(action==1){
            ui->label->setText("Add a user");
            ui->tablename->setText("User");
        }
        else if(action==2)
        {
            ui->label->setText("Aelet a user");
            ui->tablename->setText("User");
        }
        else
                {
            ui->label->setText("not counting");
                }
        load();
}

void datamanage::addUser()
{
    // Retrieve user information from QLineEdit widgets
       QString username = ui->name->text();
       QString password = ui->id->text();

       if (username.isEmpty() || password.isEmpty()) {
           // Show an error message on the label
           ui->warning->setText("Please enter a valid name and id");
           ui->warning->show();
       }
       else
       {
           QFile file(pathusr);
           if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
               return;

           bool userExist = false;
           QTextStream in(&file);
           while (!in.atEnd()) {
               QString line = in.readLine();
               QStringList fields = line.split(",");
               if (fields[0] == username) {
                   userExist = true;
                   break;
               }
           }
           file.close();
           if(userExist){
               ui->warning->setText("user already exists");
               ui->warning->show();
           }
           else{
               if (!file.open(QIODevice::WriteOnly | QIODevice::Append))
                   return;

               QTextStream stream(&file);
               stream << username << "," << password << "\n";

               file.close();
               ui->warning->hide();
           }
       }
}



void datamanage::deleteUser() {
    QString username = ui->name->text();

    if (username.isEmpty()) {
        ui->warning->setText("Please enter a valid name");
        ui->warning->show();
    } else {
        QFile file(pathusr);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            return;

        bool userExist = false;
        QTextStream in(&file);
        QStringList lines;
        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList fields = line.split(",");
            if (fields[0] != username) {
                lines << line;
            }else{
                userExist= true;
            }
        }
        file.close();

        if(!userExist){
            ui->warning->setText("user does not exist");
            ui->warning->show();
        }else{
            if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
                return;

            QTextStream out(&file);
            for (QString line : lines) {
                out << line << "\n";
            }
            file.close();
            ui->warning->hide();
        }
    }
}
datamanage::~datamanage()
{
    delete ui;
}

void datamanage::on_pushButton_2_clicked()
{

    if(action==1)
    {
     addUser();
     reload();
    }
    if(action==2)
    {
     deleteUser();
     reload();
    }
}
void datamanage::load()
{

    // Create a QStandardItemModel
       QStandardItemModel* model = new QStandardItemModel(this);

       // Set the model for the QTableView
       ui->tableView->setModel(model);

       // Open the CSV file
       QFile file(pathusr);
       if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
           return;

       QStringList headers;
       headers << "Name" << "Password";
       model->setHorizontalHeaderLabels(headers);

       // Read the CSV file and add the data to the model
       QTextStream in(&file);
       int row = -1; // set the initial value to -1
       while (!in.atEnd()) {
           QString line = in.readLine();
           QStringList fields = line.split(",");
           for (int col = 0; col < fields.size();col++) {
               QStandardItem* item = new QStandardItem(fields[col]);
               model->setItem(row, col, item);
           }
           if (row != -1) {
               row++;
           }
           else {
               row = 0;
           }
       }
       file.close();
       ui->tableView->verticalHeader()->hide();


}
void datamanage::reload()
{


    // Reload the table data
    QStandardItemModel* model = dynamic_cast<QStandardItemModel*>(ui->tableView->model());
    if (model) {
        model->clear();
        // reset header
        QStringList headers;
        headers << "Name" << "Password";
       model->setHorizontalHeaderLabels(headers);

        // Open the CSV file
        QFile file(pathusr);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            return;
        // Read the CSV file and add the data to the model
        QTextStream in(&file);
        int row = -1; // set the initial value to -1
        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList fields = line.split(",");
            for (int col = 0; col < fields.size();col++) {
                QStandardItem* item = new QStandardItem(fields[col]);
                model->setItem(row, col, item);
            }
            if (row != -1) {
                row++;
            }
            else {
                row = 0;
            }
        }
        file.close();
    }

}


void datamanage::on_Back_clicked()
{
    this->hide();
    managedb*mdl = new managedb;
    mdl->show();

}

