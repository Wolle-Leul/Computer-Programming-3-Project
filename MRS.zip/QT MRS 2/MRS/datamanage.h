#ifndef DATAMANAGE_H
#define DATAMANAGE_H

#include <QDialog>
#include <QtDebug>
#include <QtSql>
#include <QFile>
#include <QTextStream>

namespace Ui {
class datamanage;
}

class datamanage : public QDialog
{
    Q_OBJECT

public:
 explicit datamanage(QWidget *parent = nullptr, int action = 0);
    int action;
    ~datamanage();
    bool first,second,third,fourth=false;
    void addUser();
    void deleteUser();
    void load();
    void reload();

private slots:
    void on_pushButton_2_clicked();

    void on_Back_clicked();

private:
    Ui::datamanage *ui;
};

#endif // DATAMANAGE_H
