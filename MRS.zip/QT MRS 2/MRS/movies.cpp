#include "movies.h"
#include "user.h"
#include "ui_movies.h"


movies::movies(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::movies)
{
    ui->setupUi(this);;
    connect(ui->selectFileBtn, SIGNAL(clicked()), this, SLOT(selectFile()));
    connect(ui->recommendBtn, SIGNAL(clicked()), this, SLOT(recommendMovie()));
    connect(ui->actionButton, SIGNAL(clicked()), this, SIGNAL(actionButtonClicked()));
    connect(ui->dramaButton, SIGNAL(clicked()), this, SIGNAL(dramaButtonClicked()));
    connect(ui->crimeButton, SIGNAL(clicked()), this, SIGNAL(crimeButtonClicked()));
    connect(ui->adventureButton, SIGNAL(clicked()), this, SIGNAL(adventureButtonClicked()));
    connect(ui->westernButton, SIGNAL(clicked()), this, SIGNAL(westernButtonClicked()));
    connect(ui->similarButton, SIGNAL(clicked()), this, SIGNAL(similarButtonClicked()));

    connect(this, SIGNAL(actionButtonClicked()), this, SLOT(recommendActionMovie()));
     connect(this, SIGNAL(dramaButtonClicked()), this, SLOT(recommenddramaMovie()));
      connect(this, SIGNAL(crimeButtonClicked()), this, SLOT(recommendcrimeMovie()));
       connect(this, SIGNAL(adventureButtonClicked()), this, SLOT(recommendadventureMovie()));
        connect(this, SIGNAL(westernButtonClicked()), this, SLOT(recommendwesternMovie()));
    connect(this, SIGNAL(similarButtonClicked()), this, SLOT(recommendSimilarMovie()));
}

void movies::selectFile()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open CSV"), "", tr("CSV Files (*.csv)"));

    try {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) {
            QMessageBox::critical(this, "Error", "Could not open file.");
            return;
        }

        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();
            std::vector<QString> movieDataLine;
            for (const QString &cell : line.split(',')) {
                movieDataLine.push_back(cell);
            }
            movieData.push_back(movieDataLine);
        }
        file.close();
    } catch (std::exception& e) {
        QMessageBox::critical(this, "Error", e.what());
    }
}

void movies::recommendMovie()
{
    if (movieData.empty()) {
        QMessageBox::critical(this, "Error", "No movie data found. Please select a file.");
        return;
    }

    int randomIndex = rand() % movieData.size();
    ui->movieTitleLabel->setText(movieData[randomIndex][0]);
    ui->movieGenreLabel->setText(movieData[randomIndex][1]);
    ui->movieRatingLabel->setText(movieData[randomIndex][2]);
     }
void movies::recommendActionMovie()
{
    recommendGenreMovie<QString>("Action");
    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/Action.png");
    ui->picture->setPixmap(ll);
}
void movies::recommenddramaMovie()
{
    recommendGenreMovie<QString>("Drama");
    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/Drama.png");
    ui->picture->setPixmap(ll);
}
void movies::recommendcrimeMovie()
{
    recommendGenreMovie<QString>("Crime");
    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/Crime.png");
    ui->picture->setPixmap(ll);
}
void movies::recommendadventureMovie()
{
    recommendGenreMovie<QString>("Adventure");

    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/Adventure.png");
    ui->picture->setPixmap(ll);
}
void movies::recommendwesternMovie()
{
    recommendGenreMovie<QString>("Western");
    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/Western.png");
    ui->picture->setPixmap(ll);
}



template <typename T>
void movies::recommendGenreMovie(T genre)
{
    if (movieData.empty()) {
        QMessageBox::critical(this, "Error", "No movie data found. Please select a file.");
        return;
    }

    // Create a vector to store genre movies
    std::vector<std::vector<QString>> genreMovies;

    // Iterate through movieData and filter for genre movies
    for (const auto &movie : movieData) {
        if (movie[1] == genre) {
            genreMovies.push_back(movie);
        }
    }

    // If no genre movies are found
    if (genreMovies.empty()) {
        QMessageBox::critical(this, "Error", "No genre movies found.");
        return;
    }

    // Randomly select a genre movie
    int randomIndex = rand() % genreMovies.size();

    // Display the selected movie's title, genre, and rating
    ui->movieTitleLabel->setText(genreMovies[randomIndex][0]);
    ui->movieGenreLabel->setText(genreMovies[randomIndex][1]);
    ui->movieRatingLabel->setText(genreMovies[randomIndex][2]);
}


void movies::recommendSimilarMovie()
{
    if (movieData.empty()) {
        QMessageBox::critical(this, "Error", "No movie data found. Please select a file.");
        return;
    }

    // Get the entered movie name
    QString enteredMovie = ui->movieNameEdit->text();

    // Find the genre of the entered movie
    QString movieGenre;
    for (const auto &movie : movieData) {
        if (movie[0] == enteredMovie) {
            movieGenre = movie[1];
            break;
        }
    }

    // If the entered movie is not found
    if (movieGenre.isEmpty()) {
        QMessageBox::critical(this, "Error", "Entered movie not found.");
        return;
    }

    // Create a vector to store similar genre movies
    std::vector<std::vector<QString>> similarMovies;

    // Iterate through movieData and filter for similar genre movies
    for (const auto &movie : movieData) {
        if (movie[1] == movieGenre) {
            similarMovies.push_back(movie);
        }
    }

    // If no similar genre movies are found
    if (similarMovies.empty()) {
        QMessageBox::critical(this, "Error", "No similar movies found.");
        return;
    }

    // Find the highest rated similar movie
    double highestRating = -1;
    std::vector<QString> highestRatedMovie;
    for (const auto &movie : similarMovies) {
        double rating = movie[2].toDouble();
        if (rating > highestRating) {
            highestRating = rating;
            highestRatedMovie = movie;
        }
    }

    // Display the highest rated similar movie's title, genre, and rating
    ui->movieTitleLabel->setText(highestRatedMovie[0]);
    ui->movieGenreLabel->setText(highestRatedMovie[1]);
    ui->movieRatingLabel->setText(highestRatedMovie[2]);
}
movies::~movies()
     {
            delete ui;
     }

void movies::onBackclicked()
{
    this->hide();
    user*ul = new user;
    ul->show();
}

