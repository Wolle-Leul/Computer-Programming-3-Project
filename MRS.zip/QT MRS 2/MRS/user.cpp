#include "user.h"
#include "ui_user.h"
#include "movies.h"
#include "welcome.h"
#define pathu "C:/Users/Leul Wolle/Desktop/QT MRS 2/Users.csv"

user::user(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::user),
    file(pathu)
{

    ui->setupUi(this);
    QPixmap ll("C:/Users/Leul Wolle/Desktop/QT MRS 2/sighn.png");
    QPixmap welcome("C:/Users/Leul Wolle/Desktop/QT MRS 2/Welcome.png");
            ui->ll->setPixmap(ll);
            ui->lwelcome->setPixmap(welcome);


    // Open file for reading and writing
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        ui->statusu->setText("Failed to open file");
        return;
    }

    // Check if file exists
    QFileInfo checkFile(pathu);
    if (!checkFile.exists()) {
        ui->statusu->setText("File not exist");
        return;
    }

    // Check if I have permission
    if (!file.setPermissions(QFile::ReadUser | QFile::WriteUser)) {
        ui->statusu->setText("Failed to set permissions");
    } else {
        ui->statusu->setText("Connected.....");
    }
}

user::~user()
{
    file.close();
    delete ui;
}

void user::on_Ulogin_clicked()
{
    QString username, password;
    username = ui->uname2->text();
    password = ui->passd2->text();

    if (!file.isOpen()) {
        qDebug() << "Failed to open file";
        ui->statusu->setText("Failed to open file");
        return;
    }

    // Check if file exists
    QFileInfo checkFile(pathu);
    if (!checkFile.exists()) {
        ui->statusu->setText("File not exist");
        return;
    }

    // Read file and check for username and password
    QTextStream in(&file);
    in.readLine(); // skip the header row
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(",");
        if (fields[0] == username && fields[1] == password) {
            ui->statusu->setText("username and password are correct");
            this->hide();
            movies*ml = new movies;
            ml->show();
        }
    }

    ui->statusu->setText("username or password is not correct");
}


void user::on_pushButton_clicked()
{
    this->hide();
    welcome*wl = new welcome;
    wl->show();
}


void user::on_refresh_clicked()
{
    this->hide();
    user*rf = new user;
    rf->show();
}


