#ifndef MOVIES_H
#define MOVIES_H

#include <QWidget>
#include <QString>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <vector>
#include <string>
#include <map>
#include <QFileDialog>
#include <QMessageBox>
#include <algorithm>
#include <functional>


namespace Ui {
class movies;
}

class movies : public QWidget
{
        Q_OBJECT
    template <typename T>
    void recommendGenreMovie(T genre);
    signals:
            void actionButtonClicked();
            void dramaButtonClicked();
            void crimeButtonClicked();
            void adventureButtonClicked();
            void westernButtonClicked();
            void similarButtonClicked();


    public:
        explicit movies(QWidget *parent = nullptr);
        ~movies();

    private slots:
        void selectFile();
        void recommendMovie();
        void recommendActionMovie();
        void recommenddramaMovie();
        void recommendcrimeMovie();
        void recommendadventureMovie();
        void recommendwesternMovie();
        void recommendSimilarMovie();
        void onBackclicked();

private:
        Ui::movies *ui;
        std::vector<std::vector<QString>> movieData;
        std::vector<std::vector<QString>> similarMovies;
        int currentIndex;        
};

#endif // MOVIES_H
