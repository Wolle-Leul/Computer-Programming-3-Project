#ifndef MANAGEDB_H
#define MANAGEDB_H

#include <QDialog>
#include <QtDebug>
#include <QtSql>
#include <QFile>
#include <QTextStream>

namespace Ui {
class managedb;
}

class managedb : public QDialog
{
    Q_OBJECT

public:
    explicit managedb(QWidget *parent = nullptr);
    ~managedb();

private slots:
    void on_addusr_clicked();

    void on_dltusr_clicked();

    void on_pushButton_4_clicked();

    void on_Back_clicked();

private:
    Ui::managedb *ui;
    QFile fileuser;
    QFile filemovie;

};
#endif // MANAGEDB_H
