#include "welcome.h"
#include "./ui_welcome.h"
#include "user.h"
#include "admin.h"

welcome::welcome(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::welcome)
{
    ui->setupUi(this);
    QPixmap admin("C:/Users/Leul Wolle/Desktop/QT MRS 2/logo.png");
            ui->logo->setPixmap(admin);


}

welcome::~welcome()
{
    delete ui;
}


void welcome::on_touser_clicked()
{
      this->hide();
      user*userl = new user;
      userl->show();

}


void welcome::on_toadmin_clicked()
{
    this->hide();
    admin*adminl = new admin;
    adminl->show();
}

