#include "managedb.h"
#include "datamanage.h"
#include "ui_managedb.h"
#include "admin.h"

managedb::managedb(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::managedb)
{
    ui->setupUi(this);
}

managedb::~managedb()
{
    delete ui;
}

void managedb::on_addusr_clicked()
{
    this->hide();
    datamanage*addusr = new datamanage(this, 1);
    addusr->show();
}



void managedb::on_dltusr_clicked()
{
    this->hide();
    datamanage*dltusr = new datamanage(this, 2);
    dltusr->show();
}


void managedb::on_Back_clicked()
{
    this->hide();
    admin*al = new admin;
    al->show();
}

