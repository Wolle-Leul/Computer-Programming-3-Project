#ifndef ADMIN_H
#define ADMIN_H

#include <QWidget>
#include <QtDebug>
#include <QtSql>
#include <QFile>
#include <QTextStream>


namespace Ui {
class admin;
}

class admin : public QWidget
{
    Q_OBJECT

public:
    explicit admin(QWidget *parent = nullptr);
    ~admin();

private slots:
    void on_Alogin_clicked();

    void on_Back_clicked();

    void on_refresh_clicked();

private:
    Ui::admin *ui;
    QSqlDatabase mydb;
    QFile file;
};

#endif // ADMIN_H
